# Vikram K Portfolio

1. Open `index.html` in a browser to preview.
2. Replace the GitHub and LinkedIn placeholder links with your real profile URLs.
3. Upload `index.html` to a GitHub repository and enable GitHub Pages.
